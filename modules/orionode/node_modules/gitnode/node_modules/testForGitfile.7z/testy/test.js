var zlib = require('zlib');
var gf = require('gitfile.js');
var fs = require('fs');
var ph = require('path');

var file = fs.readFileSync('plik');
var gitFileObject = fs.readFileSync('.git\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');

gf.fileDataToSha1(file, function(err, sha1){
    if(err) throw err;
    if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09')
        console.log('fileDataToSha1 ok');
    else
        console.log('fileDataToSha1 wrong');
});



gf.fileDataToSha1Store(file, function(err, sha1, store){
    if(err) throw err;
    zlib.unzip(gitFileObject, function(err, buffer) {
       if(err) throw err;
       var ok = true;
       for(var i = 0; i < buffer.length; i++)
       {
           if(buffer[i] != store[i])
           {
               ok = false;
           }
       }
        if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09' && ok && buffer.length == store.length)
            console.log('fileDataToSha1Store ok');
        else
            console.log('fileDataToSha1Store wrong');
    });
});

gf.fileToSha1('plik', function(err, sha1){
    if(err) throw err;
    if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09')
        console.log('fileToSha1 ok');
    else
        console.log('fileToSha1 wrong');
});

gf.fileToSha1Store('plik', function(err, sha1, store){
    if(err) throw err;
    zlib.unzip(gitFileObject, function(err, buffer) {
       if(err) throw err;
       var ok = true;
       for(var i = 0; i < buffer.length; i++)
       {
           if(buffer[i] != store[i])
           {
               ok = false;
           }
       }
        if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09' && ok && buffer.length == store.length)
            console.log('fileToSha1Store ok');
        else
            console.log('fileToSha1Store wrong');
    });
});

gf.fileDataToBlob(file, function(err, sha1, blob){
    if(err) throw err;
    var ok = true;
    for(var i = 0; i < gitFileObject.length; i++)
    {
        if(gitFileObject[i] != blob[i])
        {
            ok = false;
        }
    }
    if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09' && ok && gitFileObject.length == blob.length)
        console.log('fileDataToBlob ok');
    else
        console.log('fileDataToBlob wrong');
});

gf.fileToBlob('plik', function(err, sha1, blob){
    if(err) throw err;
    var ok = true;
    for(var i = 0; i < gitFileObject.length; i++)
    {
        if(gitFileObject[i] != blob[i])
        {
            ok = false;
        }
    }
    if(sha1 == '66ecb87484540d6c22c9609bcea3d5bf63e52e09' && ok && gitFileObject.length == blob.length)
        console.log('fileToBlob ok');
    else
        console.log('fileToBlob wrong');
});

//gf.checkSha1Path('66ecb87484540d6c22c9609bcea3d5bf63e52e09', '.git', function(err, exist){
//    if(err) throw err;
//    if(exist)
//        console.log('checkSha1Path test 1 ok') ;
//    else
//        console.log('checkSha1Path test 1 wrong') ;
//});

fs.unlinkSync('git1\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
gf.checkSha1Path('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git1', function(err, exist){
    if(err) throw err;
    if(exist)
        console.log('checkSha1Path test 2 ok') ;
    else
        console.log('checkSha1Path test 2 wrong') ;
});

gf.checkSha1Path('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git2', function(err, exist){
    if(err) throw err;
    if(exist)
        console.log('checkSha1Path test 3 wrong');
    else
        console.log('checkSha1Path test 3 ok');
});

fs.unlinkSync('git3\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
fs.rmdirSync('git3\\objects\\66');
gf.checkSha1Path('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git3', function(err, exist){
    if(err) throw err;
    if(exist)
        console.log('checkSha1Path test 3 ok') ;
    else
        console.log('checkSha1Path test 3  wrong') ;
});

if( (ph.normalize('git\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09')) === 
    (ph.normalize(gf.getFilePath('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git'))))
{
    console.log('getFilePath ok');
    //console.log('git\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
    //console.log(gf.getFilePath('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git'));
}
else 
{
    console.log('getFilePath wrong');
    //console.log('git\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
    //console.log(gf.getFilePath('66ecb87484540d6c22c9609bcea3d5bf63e52e09', 'git'));
}
fs.unlinkSync('fakeDotGit\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');

gf.saveFileDataAsBlob(file, 'fakeDotGit');
setTimeout(function(){
    var saved = fs.readFileSync('fakeDotGit\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
    var ok1 = true;
    for(var i = 0; i < saved.length; i++)
    {
        if(saved[i] != gitFileObject[i])
        {
            ok1 = false;
        }
    }
     //console.log(saved);
     //console.log(gitFileObject);
    if(ok1 && saved.length == gitFileObject.length)
        console.log('saveFileDataAsBlob ok');
    else
        console.log('saveFileDataAsBlob wrong');
    fs.unlinkSync('fakeDotGit\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
    gf.saveFileAsBlob('plik', 'fakeDotGit');
    
    setTimeout(function(){
        var saved = fs.readFileSync('fakeDotGit\\objects\\66\\ecb87484540d6c22c9609bcea3d5bf63e52e09');
        var ok1 = true;
        for(var i = 0; i < saved.length; i++)
        {
            if(saved[i] != gitFileObject[i])
            {
                ok1 = false;
            }
        }
        //console.log(saved);
        //console.log(gitFileObject);
        if(ok1 && saved.length == gitFileObject.length)
            console.log('saveFileAsBlob ok');
        else
            console.log('saveFileAsBlob wrong');
    }, 1000);
}, 1000);

gf.blobDataToFile(gitFileObject, function(err, data){
    if(err) throw err;
    var ok = true;
    for(var i = 0; i < file.length; i++)
    {
        if(file[i] != data[i])
        {
            ok = false;
        }
    }
    if(ok && file.length == data.length)
        console.log('blobDataToFile ok');
    else
        console.log('blobDataToFile wrong');
    
    //console.log(file);
    //console.log(data);
});

gf.blobObjectToFile('66ecb87484540d6c22c9609bcea3d5bf63e52e09', '.git', function(err, data){
    if(err) throw err;
    var ok = true;
    for(var i = 0; i < file.length; i++)
    {
        if(file[i] != data[i])
        {
            ok = false;
        }
    }
    if(ok && file.length == data.length)
        console.log('blobObjectToFile ok');
    else
        console.log('blobObjectToFile wrong');
});

//gf.fileToBlob('plik', function(err, sha, blob){
//     console.log(sha);
//     console.log(blob);
//     //require('fs').writeFileSync('out', blob);
//	 
//     
//     console.log(t);
//	 
//	 console.log(blob.toString());
//	 console.log(t.toString())
//	 var b1, b2;
//	 
//	zlib.unzip(t, function(err, buffer) {
//      if (!err) {
//        console.log("t");
//		b2 = buffer;
//        console.log(buffer.toString());
//		zlib.unzip(blob, function(err, buffer) {
//		  if (!err) {
//			console.log("blob");
//			b1= buffer;
//			console.log(buffer.toString());
//			//for(var i = 0; i < b1.length; i++)
//			//{
//			//	console.log(b1.toString('utf8', i, i+1) == b2.toString('utf8', i, i+1));
//			//	
//			//}
//		  }
//		});
//      }
//    });
//	
// });